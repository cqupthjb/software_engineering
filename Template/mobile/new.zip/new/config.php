<?php
   return array(        
        'name'=>'最新手机模板', //
        'remark'=>'模板名称.', // 魔板简单介绍
        'img'=>'logo.jpg', // 后台显示魔板缩列图 相对于魔板目录路径
        'version'=>'v1.2', // 模板版本
        'author' =>'当燃', // 作者
   );
?>